package com.mycompany.leccion3practica;

import javax.swing.JOptionPane;

public class Leccion3Practica {

    public static void main(String[] args) {
        //System.out.println("Hello World!");
        //Ejercicio de while
        //Definicion de variables
        String sLectura; //variable auxiliar
        int nNumero;
        int nContador;
        int nSumatoria;
        sLectura = JOptionPane.showInputDialog("Ingresar el numero que desea calcular la sumatoria");
        
        //Asignacion de variables
        nNumero = Integer.parseInt(sLectura);
        
        //Inicializacion de variables auxiliares
        nContador = 0;
        nSumatoria = 0;
        //Funcionamiento del while
        while (nNumero >= nContador) {
            nSumatoria = nSumatoria + nContador;
            nContador++;
        }
        JOptionPane.showMessageDialog(null, "El valor de la sumatoria de 1 hasata " + nNumero + " es de " + nSumatoria);
        
        //Ejercicio de for
        nContador =0;
        nSumatoria = 0;
        for (int i = 0; i <= nNumero; i++) {
            nSumatoria = nSumatoria + i;
        }
        JOptionPane.showMessageDialog(null, "El valor de la sumatoria de 1 hasata " + nNumero + " es de " + nSumatoria);
        
        
    }
    
}
