/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leccion3sneaky;

import javax.swing.JOptionPane;

/**
 *
 * @author AMD
 */
public class Leccion3Sneaky {

    public static void main(String[] args) {

        String sLectura; //variable auxiliar
        String sNuevoTitulo;
        int nNumero;
        int nContador;
        int nSumatoria;
        //Asignacion de variables
        sLectura = JOptionPane.showInputDialog("Ingresar el titulo de la pelicula");

        if(sLectura.length()>15){
            JOptionPane.showMessageDialog(null, "La pelicula tiene un titulo largo");
            sNuevoTitulo = sLectura.substring( 0, 15);
            JOptionPane.showMessageDialog(null, sNuevoTitulo + "...");
        }else if (sLectura.length()<=15 && sLectura.length()> 5){
            JOptionPane.showMessageDialog(null, "La pelicula tiene un titulo mediano");
            JOptionPane.showMessageDialog(null, sLectura);
        }
        else {
            JOptionPane.showMessageDialog(null, "La pelicula tiene un titulo corto");
            JOptionPane.showMessageDialog(null, sLectura);
        }

        //La tienda de la ciudad
        String sCiudadTienda;
        String sCiudad;
        String sTienda;
        int nPosicionesEspacio; //Posicion Inicial
        int nPosicionesEspacioFinal; //Posicion Final
        sCiudadTienda = sLectura = JOptionPane.showInputDialog("Ingresar la ciudad y la tienda");
        sCiudadTienda = sCiudadTienda.trim(); //eliminamos espacios al inicio y al final
        nPosicionesEspacioFinal = sCiudadTienda.lastIndexOf(" ");
        nPosicionesEspacio = sCiudadTienda.indexOf(" ");
        sTienda = sCiudadTienda.substring(nPosicionesEspacioFinal + 1);
        sCiudad = sCiudadTienda.substring(0, nPosicionesEspacio);

        System.out.println(sTienda);
        System.out.println(sCiudad);

        System.out.println(sTienda.toLowerCase());
        System.out.println(sCiudad.toUpperCase());
        System.out.println(sCiudad.toUpperCase() + " " + sTienda.toLowerCase());

        //Validacion de texto inicial
        if (sCiudadTienda.trim().equals(sCiudad.toUpperCase() + " " + sTienda.toLowerCase())){
            JOptionPane.showMessageDialog(null, "Las cadenas de caracteres son iguales");
        }else{
            JOptionPane.showMessageDialog(null, "Las cadenas de caracteres no son iguales");
        }



        //nNumero = Integer.parseInt(sLectura);
    }
}
