package com.mycompany.leccion2practica;

import javax.swing.JOptionPane;

/**
 *
 * @author AMD
 */
public class Leccion2Practica {

        public static void main(String[] args) {
        System.out.println("Hello World!");

        //Ejercicio 1
        //Definicion de variables
        String sNumero1;
        int nNumero1;

        //Adquisicion de datos
        sNumero1 = JOptionPane.showInputDialog("Digite la edad");

        //Conversion de datos
        nNumero1 = Integer.parseInt(sNumero1);

        //Procesamiento de los datos
        if(nNumero1 >= 18){
            //Despliegue de informacion       
            JOptionPane.showMessageDialog(null, "Si la persona es mayor de edad");
            if(nNumero1 >= 31){     
                JOptionPane.showMessageDialog(null, "Si la persona puede ser presidente");
            }
            else{
                JOptionPane.showMessageDialog(null, "La persona no puede ser presidente");
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "La persona no es mayor de edad");  
        }


        //Ejercicio2
        //Definicion de variables
        String sNota1;
        int nNota1;

        //Adquisicion de datos
        sNota1 = JOptionPane.showInputDialog("Digite ingrese la nota del curso anterior");

        //Conversion de datos
        nNota1 = Integer.parseInt(sNota1);

        //Procesamiento de los datos
        if(nNota1 >= 70){
            //Despliegue de informacion       
            JOptionPane.showMessageDialog(null, "Usted ha aprobado el curso");   
        }
        else{
            JOptionPane.showMessageDialog(null, "Usted no ha aprobado el curso");  
        }

        //Definicion de variables
        String sMes;
        int nMes;

        //Adquisicion de datos
        sMes = JOptionPane.showInputDialog("Digite el mes");

        //Conversion de datos
        nMes = Integer.parseInt(sMes);
        switch (nMes){
            case 2:
                System.out.println("Este mes es de 28 o 29 dias");
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                System.out.println("Este mes es de 30 dias");
                break;
            default:
               System.out.println("Este mes es de 31 dias");
                break;
        }

        //Ejercicio 4
        String sLectura; //variable auxiliar
        int nNumero_1;
        int nNumero_2;
        int nNumero_3;
        sLectura = JOptionPane.showInputDialog("Ingresar primer numero");
        nNumero_1 = Integer.parseInt(sLectura);

        sLectura = JOptionPane.showInputDialog("Ingresar segundo numero");
        nNumero_2 = Integer.parseInt(sLectura);

        sLectura = JOptionPane.showInputDialog("Ingresar tercer numero");
        nNumero_3 = Integer.parseInt(sLectura);

        if(nNumero_1 == nNumero_2 && nNumero_2 == nNumero_3){
            JOptionPane.showMessageDialog(null, "Los tres numeros son iguales");
        } else if (nNumero_1 >= nNumero_2 && nNumero_1 >= nNumero_3){
            JOptionPane.showMessageDialog(null, "El primer numero es el mayor");
        } else if (nNumero_2 >= nNumero_1 && nNumero_2 >= nNumero_3){
            JOptionPane.showMessageDialog(null, "El segundo numero es el mayor");
        } else {
            JOptionPane.showMessageDialog(null, "El tercer numero es el mayor");
        }

        //Ejercicio 5
        String sLectura1;
        int nDia;
        String sMensaje;
        sLectura1 = JOptionPane.showInputDialog("Ingresar el dia de la semana");
        nDia = Integer.parseInt(sLectura1);

        switch(nDia){
            case 1:
                sMensaje = "Domingo es dia libre";
                break;
            case 2:
                sMensaje = "Lunes es dia trabajable";
                break;
            case 3:
                sMensaje = "Martes es dia trabajable";
                break;
            case 4:
                sMensaje = "Miercoles es dia trabajable";
                break;
            case 5:
                sMensaje = "Jueves es dia trabajable";
                break;
            case 6:
                sMensaje = "Viernes es dia trabajable";
                break;
            case 7:
                sMensaje = "Sabado es dia libre";
                break;
            default:
                sMensaje = "Dia invalido";
                break;                            
        }
        JOptionPane.showMessageDialog(null, sMensaje);
    }
}